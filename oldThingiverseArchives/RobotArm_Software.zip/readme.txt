Written by Florin Tobler, 2016

more information: http://www.thingiverse.com/thing:1718984